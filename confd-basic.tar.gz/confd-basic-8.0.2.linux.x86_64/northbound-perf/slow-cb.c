#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <assert.h>
#include <stddef.h>

#include <confd_lib.h>
#include <confd_dp.h>

#include <time.h>
#include <sys/time.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/poll.h>

#include "test.h"

#define LOCALHOST "127.0.0.1"

/********************************************************************/

static struct confd_daemon_ctx *dctx;
static int ctlsock;
static int workersock;
static int value = 1;

/********************************************************************/

static int s_init(struct confd_trans_ctx *tctx)
{
    confd_trans_set_fd(tctx, workersock);
    return CONFD_OK;
}

/********************************************************************/

static int get_elem(struct confd_trans_ctx *tctx,
                    confd_hkeypath_t *keypath)
{
    confd_value_t v;
    CONFD_SET_UINT32(&v, value);
    sleep(3);  // "calculating..."
    confd_data_reply_value(tctx, &v);
    return CONFD_OK;
}

/********************************************************************/

int main(int argc, char *argv[])
{
    int debuglevel = CONFD_TRACE;

    struct sockaddr_in addr;
    struct confd_trans_cbs trans;
    struct confd_data_cbs data;

    /* Initialize confd library */

    confd_init("slow-cb", stderr, debuglevel);

    memset(&addr, 0, sizeof(addr));
    addr.sin_addr.s_addr = inet_addr(LOCALHOST);
    addr.sin_family = AF_INET;
    addr.sin_port = htons(CONFD_PORT);

    if (confd_load_schemas((struct sockaddr *)&addr, sizeof(struct sockaddr_in)) != CONFD_OK)
        confd_fatal("Failed to load schemas from confd\n");

    if ((dctx = confd_init_daemon("slow-cb")) == NULL)
        confd_fatal("Failed to initialize daemon\n");

    /* Create and connect the control and worker sockets */

    if ((ctlsock = socket(PF_INET, SOCK_STREAM, 0)) < 0)
        confd_fatal("Failed to open ctlsocket\n");
    if (confd_connect(dctx, ctlsock, CONTROL_SOCKET, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) < 0)
        confd_fatal("Failed to confd_connect() to confd \n");

    if ((workersock = socket(PF_INET, SOCK_STREAM, 0)) < 0)
        confd_fatal("Failed to open workersocket\n");
    if (confd_connect(dctx, workersock, WORKER_SOCKET, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) < 0)
        confd_fatal("Failed to confd_connect() to confd \n");

    /* Register callbacks */

    memset(&trans, 0, sizeof(trans));
    trans.init = s_init;
    if (confd_register_trans_cb(dctx, &trans) == CONFD_ERR)
        confd_fatal("Failed to register trans cb\n");

    memset(&data, 0, sizeof(struct confd_data_cbs));
    data.get_elem = get_elem;
    strcpy(data.callpoint, test__callpointid_slowcp);
    if (confd_register_data_cb(dctx, &data) == CONFD_ERR)
        confd_fatal("Failed to register data cb\n");

    if (confd_register_done(dctx) != CONFD_OK)
        confd_fatal("Failed to complete registration \n");


    fprintf(stderr, "Running...\n");
    while (1)
    {
        struct pollfd set[3];
        int ret;

        set[0].fd = ctlsock;
        set[0].events = POLLIN;
        set[0].revents = 0;

        set[1].fd = workersock;
        set[1].events = POLLIN;
        set[1].revents = 0;

        if (poll(set, sizeof(set) / sizeof(set[0]), -1) < 0)
        {
            perror("Poll failed:");
            continue;
        }

        if (set[0].revents & POLLIN)
        {
            if ((ret = confd_fd_ready(dctx, ctlsock)) == CONFD_EOF)
            {
                confd_fatal("Control socket closed\n");
            }
            else if (ret == CONFD_ERR && confd_errno != CONFD_ERR_EXTERNAL)
            {
                confd_fatal("Error on control socket request: %s (%d): %s\n",
                            confd_strerror(confd_errno), confd_errno, confd_lasterr());
            }
        }
        if (set[1].revents & POLLIN)
        {
            if ((ret = confd_fd_ready(dctx, workersock)) == CONFD_EOF)
            {
                confd_fatal("Worker socket closed\n");
            }
            else if (ret == CONFD_ERR && confd_errno != CONFD_ERR_EXTERNAL)
            {
                confd_fatal("Error on worker socket request: %s (%d): %s\n",
                            confd_strerror(confd_errno), confd_errno, confd_lasterr());
            }
        }
    }
}
